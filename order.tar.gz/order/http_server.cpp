#include"httplib.h"

int main(){
 
  httplib::Server server;
  server.Get("")

  return 0;
}
